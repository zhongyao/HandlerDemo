package com.hongri.handler;

/**
 * @author youku
 */
public interface MyInterface {
	
	void refreshUI(Object obj);
	
}
