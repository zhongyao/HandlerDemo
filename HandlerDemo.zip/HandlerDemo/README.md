# Handler blog内容更新：

### [Handler运行机制](https://blog.csdn.net/u012440207/article/details/51113340)
### [Android Handler,MessageQueue,Looper源码解析](https://blog.csdn.net/u012440207/article/details/88667195)
### [Android Handler造成内存泄露的分析和解决](https://blog.csdn.net/u012440207/article/details/51195064)
### [IdleHandler原理以及延迟初始化方案实现](https://blog.csdn.net/wangsf1112/article/details/106027564) 